//Write your controller (JS code) code here

//Focus here and F11 to full screen editor

//This function will be call once to init components
vm.initLiveComponent = function(){
anychart.onDocumentReady(function () {
  var data = preprocessData([
    ['PRE-COVID', 'Tasa \n desempleo', 34, 23],
    ['PRE-COVID', 'KM \n urbanizados', 54, 15],
    ['PRE-COVID', 'Tasa \n pobreza', 50,21],
    ['PRE-COVID', 'Tasa \n dependencia \n demografica', 39,24],
    ['PRE-COVID', 'Tasa \n analfabetismo', 48,10],
    ['POST-COVID', 'Tasa \n desempleo', 76, 52],
    ['POST-COVID', 'KM \n urbanizados', 77,43],
    ['POST-COVID', 'Tasa \n pobreza', 72,48],
    ['POST-COVID', 'Tasa \n dependencia \n demografica', 79,57],
    ['POST-COVID', 'Tasa \n analfabetismo', 89,69]
  ]);

  var chart = anychart.column();

  // configure global settings for series labels
  chart.labels({position:'top'});
	
  // add subcategory names to the meta of one of the series
  var tasaMediaEspaña = chart.column(data.mapAs({'year': 0, 'value': 2,'sub-category': 1}));
  var tasaMediaGuada = chart.column(data.mapAs({'year': 0, 'value': 3,'sub-category': 1}));

  	tasaMediaEspaña.name("Tasa media España");
  
  // configure the visual settings of the first series
    tasaMediaEspaña.normal().fill("#dd0003", 0.3);
    tasaMediaEspaña.hovered().fill("#dd0003", 0.1);
    tasaMediaEspaña.selected().fill("#dd0003", 0.5);
    tasaMediaEspaña.normal().stroke("#dd0003", 1, "10 5", "round");
    tasaMediaEspaña.hovered().stroke("#dd0003", 2, "10 5", "round");
    tasaMediaEspaña.selected().stroke("#dd0003", 4, "10 5", "round");
  
    tasaMediaGuada.name("Tasa media Guadalajara");
  

 // configure the visual settings of the second series
    tasaMediaGuada.normal().fill("#eaaf19", 0.4);
    tasaMediaGuada.hovered().fill("#eaaf19", 0.1);
    tasaMediaGuada.selected().fill("#eaaf19", 0.5);
    tasaMediaGuada.normal().hatchFill("forward-diagonal", "#eaaf19", 1, 15);
    tasaMediaGuada.hovered().hatchFill("forward-diagonal", "#eaaf19", 1, 15);
    tasaMediaGuada.selected().hatchFill("forward-diagonal", "#eaaf19", 1, 15);
    tasaMediaGuada.normal().stroke("#eaaf19");
    tasaMediaGuada.hovered().stroke("#eaaf19", 2);
    tasaMediaGuada.selected().stroke("#eaaf19", 4);
 
  
  // use subcategory names as names of X-axis ticks
  chart.xScale().names('sub-category');

  chart.xAxis().labels().rotation(300);
  chart.xAxis().labels().anchor("center");
  chart.xAxis().overlapMode('disallow-overlap');

  // set a container and draw the chart
  chart.container('container').draw();

  // calculate extra axes
  createTwoLevelAxis(chart, data);
});

function preprocessData(data){
  // to make beautiful spacing between categories, add
  // several empty lines with the same category names to the data
  if (data.length > 0) {
    // add one to the beginning of the array
    data.unshift([data[0][0]]);
    // add one more to the end of the data
    data.push([data[data.length - 1][0]]);
    // add two empty items every time the category name changes,
    // to each category
    for (var i = 2; i < data.length - 1; i++) {
      var previous = data[i-1][0];
      var current = data[i][0];
      if (current!=previous) {
        data.splice(i, 0, [previous], [current]);
        i = i+2;
      } 
      else {
        data.splice(i, 0, [previous]);
        i += 1;
      }
    }
  }
  return anychart.data.set(data);
}

function createTwoLevelAxis(chart, data, padding){
  // subcategory names
  var names = [];
  // ticks for axes based on on main categories
  var ticks = [];
  // weights of ticks (to make spacing between categories by using
  // the empty lines created in preprocessData)
  var weights = [];
  // the iterator feature allows us to go over data, so
  // create an iterator for the new breakdown
  var iter = data.mapAs({'category': 0, 'sub-category': 1}).getIterator();
  while(iter.advance()) {
    var name = iter.get('category');
    var value = iter.get('sub-category');
    // store category names
    names.push(name);
    // when the border between categories is identified, create a tick
    if (name && names[names.length - 1] != names[names.length - 2]) 					{
      ticks.push(iter.getIndex());
    }
    // assign weight to the tick
    weights.push(value?0.5:0.2);
  }

  // create a custom scale
  var customScale = anychart.scales.ordinal();
  // supply values from the chart to the scale
  customScale.values(chart.xScale().values());
  // names and ticks of main categories only
  customScale.names(names);
  customScale.ticks(ticks);

  // synchronize weights with the chart scale
  chart.xScale().weights(weights);

  // disable ticks along the main axis
    chart.xAxis(0,false);
 
  // create an extra chart axis
  chart.xAxis(1)
    .orientation('top')  
    .scale(customScale)
    .ticks(true);

  chart.xAxis(1).ticks().length(60).position('center');
  chart.xAxis(1).labels()
    .offsetY(30)
    .fontSize(12)
    .fontFamily('Titillium Web, sans-serif');

  chart.xGrid(0).scale(customScale);

  chart.title('Impacto de coyuntura covid en las variables estudiadas');
  chart.title().fontFamily('Titillium Web, sans-serif');

  //format tooltip title
  chart.tooltip().titleFormat("{%year}");
  chart.tooltip().format("{%sub-category}: {%value} %");
  
  var legend = chart.legend();
  // draw line to separate title
  legend.titleSeparator(true);
  // enable legend
  legend.enabled(true);
  // set legend position
  legend.position("bottom");
  // set legend align
  legend.align("center");
  // set items layout
  legend.itemsLayout("horizontal");
  // change font size
  legend.fontSize(10);

}
 };


//This function will be call when data change. On first execution oldData will be null
vm.drawLiveComponent = function(newData, oldData){

};

//This function will be call on element resize
vm.resizeEvent = function(){

}

//This function will be call when element is destroyed
vm.destroyLiveComponent = function(){

};

//This function will be call when receiving a value from vm.sendValue(idGadgetTarget,data)
vm.receiveValue = function(data){

};