//Write your controller (JS code) code here

//Focus here and F11 to full screen editor

//This function will be call once to init components
vm.initLiveComponent = function(){
  
$scope.$watchCollection('vm.datastatus', vm.refreshValues);  
};
vm.refreshValues = function(){
var dom = document.getElementById("barLines");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = {
     xAxis: {
        type: 'category',
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        type: 'bar'
    }]  
};
  if (vm.option && typeof vm.option === "object") {
      vm.myChart.setOption(vm.option, true);
      vm.myChart.resize()
  }
  

 };


//This function will be call when data change. On first execution oldData will be null
vm.drawLiveComponent = function(newData, oldData){
var dom = document.getElementById("barLines");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = null;
var colors = ['#dd0003', '#eaaf19', '#1953ff'];

vm.option = {
    color: colors,
    tooltip: {
        trigger: 'axis',
    },
    title: {
        text: 'Evolucion comparativa indice vulnerabilidad',
        textStyle:{
            color: 'grey',
            fontSize: 15,
            fontWeight: "normal",
            fontFamily:'Titillium Web, sans-serif'    
        },
        top: '3%',
        left: "center",
    },
    grid: {
        right: '10%'
    },
    legend: {
        data: ['Guadalajara', 'Brihuega', 'España'],
        textStyle:{
            fontFamily:'Titillium Web, sans-serif',
        },
        bottom:'3%'
    },
    xAxis: [
        {
            type: 'category',
            axisTick: {
                alignWithLabel: true
            },
            data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
        }
    ],
    yAxis: [
        {
            type: 'value',
            name: 'Guadalajara',
            min: 0,
            max: 100,
            position: 'right',
            axisLine: {
                lineStyle: {
                    color: colors[0]
                }
            },
            show: false,
        },
        {
            type: 'value',
            name: 'Brihuega',
            min: 0,
            max: 100,
            position: 'right',
            offset: 80,
            axisLine: {
                lineStyle: {
                    color: colors[1]
                }
            },
            show: false,
        },
        {
            type: 'value',
            name: 'España',
            min: 0,
            max: 100,
            position: 'left',
            axisLine: {
                lineStyle: {
                    color: colors[2]
                }
            },
            show: false,
        },
        {
            type: 'value',
            name: '',
            fontSize: '8px',
            fontFamily: 'Titillium Web, sans-serif',
            left: '7%',
            min: 0,
            max: 100,
            position: 'left',
            axisLine: {
                lineStyle: {
                    color: colors[2]
                }
            },
            axisLabel: {
                formatter: '{value}'
            },
            show: true
        }
    ],
    series: [
        {
            name: 'Guadalajara',
            type: 'bar',
            data: [1, 12, 34, 36, 30, 22, 10, 11, 0.00, 0.00, 0.00, 0.00]
        },
        {
            name: 'Brihuega',
            type: 'bar',
            yAxisIndex: 1,
            data: [2, 15, 30, 38, 34, 29, 8, 7, 0.00, 0.0, 0.0, 0.0]
        },
        {
            name: 'España',
            type: 'line',
            yAxisIndex: 2,
            data: [1.5, 10, 30, 27, 31, 12, 14, 12, 0.00, 0.00, 0.00, 0.00]
        }
    ]
};
;
if (vm.option && typeof vm.option === "object") {
    vm.myChart.setOption(vm.option, true);
    vm.myChart.resize()
}
};

//This function will be call on element resize
vm.resizeEvent = function(){

}

//This function will be call when element is destroyed
vm.destroyLiveComponent = function(){

};

//This function will be call when receiving a value from vm.sendValue(idGadgetTarget,data)
vm.receiveValue = function(data){

};