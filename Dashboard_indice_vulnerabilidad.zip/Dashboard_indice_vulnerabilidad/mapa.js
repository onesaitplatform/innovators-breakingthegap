//This function will be call once to init components
vm.initLiveComponent = function(){
    // var mymap = L.map('mapid', { zoomControl:true }).setView([4.060868, -74.297333], 6);
    // L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    //     attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap<\/a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA<\/a>, Imagery © <a href="https://www.mapbox.com/">Mapbox<\/a>',
    //     maxZoom: 19,
    //     id: 'mapbox/streets-v11',
    //     tileSize: 512,
    //     zoomOffset: -1,
    //     accessToken: 'pk.eyJ1IjoiY2hhcmxpZTc3NzciLCJhIjoiY2s5ZTVteGhoMDhkazNtdWtyemlyYTVrMyJ9.daB4OItJTF3kl01JpLMGeA'
    //     }).addTo(mymap);
};

//This function will be call when data change. On first execution oldData will be null
vm.drawLiveComponent = function(newData, oldData){

var polygons = {};
polygons.features = newData.map(d => d.datosGuadalajara);
console.log(polygons);

var popup = L.popup([4,4]);

var mymap = L.map('mapid', { zoomControl:true }).setView([40.7233300, -2.8500000], 8);
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap<\/a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA<\/a>, Imagery © <a href="https://www.mapbox.com/">Mapbox<\/a>',
        maxZoom: 19,
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoiY2hhcmxpZTc3NzciLCJhIjoiY2s5ZTVteGhoMDhkazNtdWtyemlyYTVrMyJ9.daB4OItJTF3kl01JpLMGeA'
        }).addTo(mymap);

L.geoJson(polygons).addTo(mymap);    

// Creamos el color 
function getColor(d) {
    return d > '0,009' ? '#bd0026' :
           d > '0,007'  ? '#f03b20' :
           d > '0,005'  ? '#fd8d3c' :
           d > '0,003'  ? '#feb24c' :
           d > '0,001'   ? '#fed976' :
                      '#ffffb2';
}

// Insertamos el color en los poligonos
function style(feature) {
    return {
        fillColor: getColor(feature.data.indice_vulnerabilidad),
        weight: 2,
        opacity: 1,
        color: 'white',
        dashArray: '3',
        fillOpacity: 0.7
    };
}

var geojson;
geojson = L.geoJson(polygons, {style: style})
geojson.addTo(mymap);

// Hacemos un hover al pasar el raton por encima
function highlightFeature(e) {
    var layer = e.target;

    layer.setStyle({
        weight: 5,
        color: '#666',
        dashArray: '',
        fillOpacity: 0.7
    });

    if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
        layer.bringToFront();
        popup
        .setLatLng(e.latlng)
        .setContent(e.target.feature.properties.municipio,e.target.feature.data.indice_vulnerabilidad)
        .openOn(mymap);
    }
}

// reset del hover
function resetHighlight(e) {
    geojson.resetStyle(e.target);
}

// al hacer click aumenta el municipio
function zoomToFeature(e) {
    mymap.fitBounds(e.target.getBounds());
}

function onEachFeature(feature, layer) {
    layer.on({
        mouseover: highlightFeature,
        mouseout: resetHighlight,
        click: zoomToFeature
    });
}

function zoomOut() {
    
}

geojson = L.geoJson(polygons, {
    style: style,
    onEachFeature: onEachFeature
}).addTo(mymap);

var legend = L.control({position: 'bottomleft'});

legend.onAdd = function (map) {

    var div = L.DomUtil.create('div', 'info legend'),
        grades = [0, '0,001', '0,003', '0,005', '0,007', '0,009'],
        grades_por = [0, '1%', '3%', '5%', '7%', '9%'],
        labels = ['<strong>Indice de vulnerabilidad</strong>'];

    // loop through our density intervals and generate a label with a colored square for each interval
    for (var i = 0; i < grades.length; i++) {
    labels.push(
        '<i style="background:' + getColor(grades[i] + 1) + '"></i> ' +
            grades_por[i] + (grades_por[i + 1] ? '&ndash;' + grades_por[i + 1] : '+'));
        }
        div.innerHTML = labels.join('<br>');
        return div;
};


legend.addTo(mymap);

};

//This function will be call on element resize
vm.resizeEvent = function(){

}

//This function will be call when element is destroyed
vm.destroyLiveComponent = function(){

};

//This function will be call when receiving a value from vm.sendValue(idGadgetTarget,data)
vm.receiveValue = function(data){

};