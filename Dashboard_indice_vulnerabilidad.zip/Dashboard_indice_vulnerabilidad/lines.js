//Write your controller (JS code) code here

//Focus here and F11 to full screen editor

vm.initLiveComponent = function(){
  
$scope.$watchCollection('vm.datastatus', vm.refreshValues);  
};
vm.refreshValues = function(){
var dom = document.getElementById("lineas");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = {
     xAxis: {
        type: 'category',
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        type: 'bar'
    }]  
};
  if (vm.option && typeof vm.option === "object") {
      vm.myChart.setOption(vm.option, true);
      vm.myChart.resize()
  }
  

 };

//This function will be call when data change. On first execution oldData will be null
vm.drawLiveComponent = function(newData, oldData){
var dom = document.getElementById("lineas");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = null;
vm.option = {
    title: {
        text: 'Evolución temporal de cada variable analizada',
        textStyle:{
            color: 'grey',
            fontSize: 15,
            fontWeight: "normal",
            fontFamily:'Titillium Web, sans-serif'    
        },
        left: "center",
    },
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        data: ['Desempleo', 'Km. urbanizables', 'Pobreza', 'Dependencia demográfica', 'Analfabetismo'],
        left: "9%",
        bottom:'3%',
        textStyle:{
            fontFamily:'Titillium Web, sans-serif',
        }
    },
    grid: {
        left: '3%',
        right: '4%',
        top: '13%',
        bottom: '15%',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        boundaryGap: false,
        show: true,
        data: ['2014','2015', '2016', '2017', '2018', '2019', '2020']
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name: 'Desempleo',
            type: 'line',
            data: [4, 6, 8, 10, 5, 14, 15]
        },
        {
            name: 'Km. urbanizables',
            type: 'line',
            data: [19, 18, 17, 14, 12, 19, 20]
        },
        {
            name: 'Pobreza',
            type: 'line',
            data: [25, 27, 24, 26, 30, 35, 39]
        },
        {
            name: 'Dependencia demográfica',
            type: 'line',
            stack: 'tasas',
            data: [30, 32, 28, 31, 35, 40, 43]
        },
        {
            name: 'Analfabetismo',
            type: 'line',
            data: [53, 62, 52, 60, 75, 84, 88]
        }
    ]
};
;
if (vm.option && typeof vm.option === "object") {
    vm.myChart.setOption(vm.option, true);
    vm.myChart.resize();
}
};

//This function will be call on element resize
vm.resizeEvent = function(){
    
}

//This function will be call when element is destroyed
vm.destroyLiveComponent = function(){
    if(vm.myChart){
    	vm.myChart.clear();
  		vm.myChart = null;
    }
};

//This function will be call when receiving a value from vm.sendValue(idGadgetTarget,data)
vm.receiveValue = function(data){

};